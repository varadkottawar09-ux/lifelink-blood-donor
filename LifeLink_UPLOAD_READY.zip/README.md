# LifeLink – Blood Donor Management System

A responsive Flask + SQLite student project.

## Features
- Home page with donor and open-request counts
- Donor registration (name, blood group, city, mobile, email)
- Search available donors by blood group and city
- Call/email links on donor cards
- Emergency blood request form
- Admin dashboard to view donors and requests, toggle donor availability, delete donor records, and close requests
- SQLite database is created automatically

## Run on your computer
1. Install Python 3.10 or newer.
2. Extract the ZIP and open the folder in VS Code.
3. Open Terminal and run:
   ```bash
   pip install -r requirements.txt
   python app.py
   ```
4. Open `http://127.0.0.1:5000`

## Demo admin login
- Username: `admin`
- Password: `LifeLink@123`

Change these before making the website public by setting environment variables:
- `ADMIN_USER`
- `ADMIN_PASSWORD`
- `SECRET_KEY`

## Deploying
This is a Flask web application, not a static HTML site. Deploy it as a Python web service using:
- Build command: `pip install -r requirements.txt`
- Start command: `gunicorn app:app`

Set a persistent disk and set `DATABASE_PATH` to a file on that disk, or configure a managed database, so registrations are not lost when the hosting service restarts/redeploys. Set a strong `SECRET_KEY` and new admin credentials.

## Important
This is a student demonstration project and does not verify medical eligibility, blood compatibility, or donor availability. Confirm all medical details with a qualified healthcare professional. Donors' phone numbers are visible to visitors who search the directory; register only with informed consent.
