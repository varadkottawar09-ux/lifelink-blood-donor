import os, sqlite3
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, flash, session, g

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret-before-deployment")
DB_PATH = os.environ.get("DATABASE_PATH", os.path.join(os.path.dirname(__file__), "lifelink.db"))
ADMIN_USER = os.environ.get("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "LifeLink@123")

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS donors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, blood_group TEXT NOT NULL, city TEXT NOT NULL,
            phone TEXT NOT NULL, email TEXT, availability TEXT NOT NULL DEFAULT 'Available',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_name TEXT NOT NULL, blood_group TEXT NOT NULL, city TEXT NOT NULL,
            hospital TEXT, phone TEXT NOT NULL, details TEXT, status TEXT DEFAULT 'Open',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )""")

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("admin"):
            flash("Please log in to access the admin dashboard.", "error")
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapped

@app.route("/")
def home():
    total = db().execute("SELECT COUNT(*) FROM donors WHERE availability='Available'").fetchone()[0]
    requests_count = db().execute("SELECT COUNT(*) FROM requests WHERE status='Open'").fetchone()[0]
    return render_template("index.html", total=total, requests_count=requests_count)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        data = [request.form.get(k, "").strip() for k in ("name","blood_group","city","phone","email")]
        if not all(data[i] for i in (0,1,2,3)):
            flash("Please complete all required fields.", "error")
        else:
            db().execute("INSERT INTO donors(name,blood_group,city,phone,email) VALUES(?,?,?,?,?)", data)
            db().commit()
            flash("Thank you! Your donor registration has been saved.", "success")
            return redirect(url_for("home"))
    return render_template("register.html")

@app.route("/search")
def search():
    group = request.args.get("blood_group", "").strip()
    city = request.args.get("city", "").strip()
    sql = "SELECT * FROM donors WHERE availability='Available'"
    params = []
    if group:
        sql += " AND blood_group=?"; params.append(group)
    if city:
        sql += " AND city LIKE ?"; params.append(f"%{city}%")
    sql += " ORDER BY created_at DESC"
    donors = db().execute(sql, params).fetchall()
    return render_template("search.html", donors=donors, group=group, city=city)

@app.route("/request-blood", methods=["GET", "POST"])
def request_blood():
    if request.method == "POST":
        keys = ("patient_name","blood_group","city","hospital","phone","details")
        values = [request.form.get(k, "").strip() for k in keys]
        if not all(values[i] for i in (0,1,2,4)):
            flash("Please complete the required fields.", "error")
        else:
            db().execute("""INSERT INTO requests(patient_name,blood_group,city,hospital,phone,details)
                         VALUES(?,?,?,?,?,?)""", values)
            db().commit()
            flash("Your blood request has been submitted.", "success")
            return redirect(url_for("home"))
    return render_template("request.html")

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        if request.form.get("username") == ADMIN_USER and request.form.get("password") == ADMIN_PASSWORD:
            session["admin"] = True
            return redirect(url_for("admin_dashboard"))
        flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/admin/logout")
def admin_logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/admin")
@admin_required
def admin_dashboard():
    donors = db().execute("SELECT * FROM donors ORDER BY created_at DESC").fetchall()
    requests = db().execute("SELECT * FROM requests ORDER BY created_at DESC").fetchall()
    return render_template("admin.html", donors=donors, requests=requests)

@app.route("/admin/donor/<int:donor_id>/availability", methods=["POST"])
@admin_required
def donor_availability(donor_id):
    current = db().execute("SELECT availability FROM donors WHERE id=?", (donor_id,)).fetchone()
    if current:
        new_value = "Unavailable" if current["availability"] == "Available" else "Available"
        db().execute("UPDATE donors SET availability=? WHERE id=?", (new_value, donor_id))
        db().commit()
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/donor/<int:donor_id>/delete", methods=["POST"])
@admin_required
def delete_donor(donor_id):
    db().execute("DELETE FROM donors WHERE id=?", (donor_id,))
    db().commit()
    flash("Donor record deleted.", "success")
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/request/<int:req_id>/close", methods=["POST"])
@admin_required
def close_request(req_id):
    db().execute("UPDATE requests SET status='Closed' WHERE id=?", (req_id,))
    db().commit()
    return redirect(url_for("admin_dashboard"))

@app.route("/health")
def health():
    return {"status": "ok"}

init_db()
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
